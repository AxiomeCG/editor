# Environment executable lab

The Environment lab is the plugin's executable living documentation. It loads production `SceneGraph` fixtures, the production Environment presentation contribution, the production Environment panel, and the real editor actions. It does not maintain a second renderer or a lab-only water, vegetation, surroundings, atmosphere, or weather implementation.

The catalog is public at `@pascal-app/plugin-environment/lab/catalog`; fixture and control integration is public at `@pascal-app/plugin-environment/lab`.

With the local host running on port 3001, open the [Environment lab](http://localhost:3001/environment-lab) at `/environment-lab`.

## Exhibit modes

| Mode | Purpose | Cases |
|---|---|---|
| Gym | Perform a focused authoring operation and observe a specific result. | `ground-cover-brushes`, `pond-basins`, `river-authoring`, `weather` |
| Zoo | Compare true-scale variants under fixed framing. | `surface-materials`, `grass-obstacles`, `pond-life`, `natural-presets` |
| Museum | Follow a curated explanation with camera stations and source links that require access to the Environment repository. | `river-endpoints`, `regional-surroundings`, `night-landmarks`, `sky-and-sun`, `portability`, `living-landscape` |

Case IDs and variant IDs are stable review addresses. Every descriptor has a version, initial camera, review steps, source files, camera stations, and named variants. `createEnvironmentLabFixture(caseId, variantId?)` uses the first variant when no variant is supplied and throws for an unknown case or variant.

Catalog source URLs target the actual `AxiomeCG/environment` repository on its `main` branch. The repository is private, so unauthenticated readers receive `404`; use an account with repository access or the relative source links in these checked-out guides.

## Feature coverage

| Production feature | Primary executable cases |
|---|---|
| Surface PBR channels, texture size, blending, terrain drape, Site-edge feathering, 2D paint and current-production GLB inspection | `surface-materials`, `regional-surroundings`, `portability` |
| Ground Cover coverage/height brushes, shapes, fill/clear/reset, appearance, flowers, wind, bend and flattening | `ground-cover-brushes`, `grass-obstacles` |
| Building/solid and resolved wet-water exclusions; grass reappearance after drain/remove | `grass-obstacles`, `living-landscape` |
| Terrain-derived pond basins, levels, connected seeds, qualities, shores, lilies and koi | `pond-basins`, `pond-life`, `living-landscape` |
| River draw/edit/cancel/undo/delete, channel grading/restoration, endpoints, shores, direction and speed | `river-authoring`, `river-endpoints`, `living-landscape` |
| Regional roads/frontages/access/style metadata, homes, trees, shadows, coastline, continuation, fields, commerce, skyline, boulders and lighthouse | `regional-surroundings`, `river-endpoints`, `night-landmarks` |
| Open Meadow and Woodland Edge grass, flowers, detailed/distant trees, clearings and birds | `natural-presets` |
| Procedural/gradient sky, presets, time/manual sun, north, scattering, clouds, fog, moon, exposure and debug views | `sky-and-sun` |
| Rain, snow, wind, storm, wetness/snow overlays, lightning, consent-gated thunder and lifecycle limits | `weather`, `living-landscape` |
| Semantic Environment nodes, versioned presentation sidecar, current material-baked GLB inspection, separate editable Review JSON and honest fidelity limits | `portability` |
| Complete combined production composition | `living-landscape` |

The [case-by-case review guide](./cases.md) names every variant and inspection target. [Reproducibility, lifecycle, performance and portability](./reproducibility.md) documents what a result means and what it does not mean.

## Production interfaces

```ts
import {
  EnvironmentLabControls,
  createEnvironmentLabFixture,
  initializeEnvironmentLabFixture,
} from '@pascal-app/plugin-environment/lab'
import {
  ENVIRONMENT_LAB_CASES,
  ENVIRONMENT_LAB_FEATURES,
  getEnvironmentLabCase,
} from '@pascal-app/plugin-environment/lab/catalog'

const fixture = createEnvironmentLabFixture('pond-life', 'deep-life')
initializeEnvironmentLabFixture('pond-life', fixture)
```

A host owns routing, scratch persistence, scene replacement, camera controls and review downloads. The plugin owns only catalog metadata, detached fixtures, session initialization, and the real Environment panel re-export.

Each fixture uses current schema parsers and a real hierarchy:

```text
Site
├── Building → Level                        (stable floorplan context in every fixture)
│   └── Slab / Block                        (where an obstacle/reference is needed)
├── Ground Cover                            (when authored)
├── Surface                                 (when authored)
├── Pond                                    (when authored)
└── River                                   (when authored)
```

Environment nodes are direct Site children. Every fixture also supplies `building_lab-<case>` and `level_lab-<case>` as ordinary graph context so the host can select a real level for 2D or Split review; host selection still goes through the viewer selection API after graph replacement, not through fixture metadata. Terrain and RGBA authoring fields use the current production encoders. River fixtures call the current terrain grading path so source terrain, applied excavation and restoration metadata are real. Pond fixtures call the basin resolver and use only an accepted bottom/spill ladder. Every graph declares `pascal:environment` in `installedPlugins`.

## Review workflow

1. Open [the local lab index](http://localhost:3001/environment-lab), choose a case by stable ID, and choose a named variant.
2. Read the case's authored starting state and production limitations.
3. For a Gym, perform the named action with the real panel and editor command system.
4. For a Zoo, compare variants at the same station and rendering profile.
5. For a Museum, move through every numbered station and follow its source links with repository access.
6. Restore the canonical fixture before comparing another run.
7. Download the review record when evidence needs to be discussed. Treat it as evidence, not as a self-approving baseline.

Image comparisons are useful evidence, but do not replace semantic checks, focused authoring checks, failure-state checks, performance measurements, or human perceptual review.
