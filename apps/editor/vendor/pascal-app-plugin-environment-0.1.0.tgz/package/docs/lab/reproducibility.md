# Environment lab reproducibility and review contract

## Deterministic setup

A lab reset replaces the scratch graph with a newly constructed fixture, imports its versioned Environment configuration, restores the case camera, and resets plugin-session controls. It also clears Pond and River authoring modes, targets, previews and feedback; resets catalogue/water tabs and brush/tool defaults; stops sky playback/cloud motion; enables birds and ordinary ambient motion unless the selected variant says otherwise; and explicitly turns thunder audio off and closes the thunder session.

Fixture construction is detached. Every call creates new parsed nodes, encoded terrain and paint buffers, configuration objects and camera tuples. A fixture never shares mutable graph or configuration state with another case or reset.

All authored fixture IDs are semantic and stable inside a case:

- `site_lab-<case>`
- `building_lab-<case>` → `level_lab-<case>` → `slab_lab-<case>` / `block_lab-<case>`
- `grass-field_lab-<case>`
- `surface-material_lab-<case>`
- `pond_lab-<case>`
- `river_lab-<case>`

Stable fixture IDs are review addresses, not an instruction for user-authored nodes to stop using generated IDs.

## Units and scale

Pascal and Environment use metres in authored node geometry and terrain spacing. Terrain values are signed integer samples multiplied by their encoded `step`; lab terrain uses 0.01 m quantization. Grass blade dimensions, brush radii, water width/depth, prop positions, camera positions and surrounding geometry remain at production world scale. Surface `textureSize` is a percent-like production control bounded from 25 through 200, not a texture pixel dimension.

The lab deliberately uses measured fields and fixed camera stations. A close-up that rescales a blade, road, pond or building until it “looks right” is not equivalent evidence.

New Ground Cover fields default to 0.30 m blade height, and the lab uses that shared production default rather than a separate short-grass override. Explicit authored heights are preserved; the existing legacy-scale migration remains unchanged in scope.

## Seeds, variants and assets

`pascal-suburbs` is the fixed proven coastal seed used for endpoint, regional and combined exhibits. `environment-lab-8` is the fixed inland endpoint seed. The night-landmarks exhibit uses the independently proven coastal `environment-lab-night-2295` seed because its current production plan supplies a lighthouse, viable gas-station and supermarket lots, and a parked car without the road-presentation fallback. Natural presets run through their real policy, which forces inland landscape context and suppresses built/coastal/regional-water families.

Surface material textures and the tree implementation are bundled package assets. Fixture source contains no arbitrary external model or image URL. Review does not depend on a remote CDN being available.

Named variants change production graph or configuration state; they are not CSS filters or lab-only decorators. Catalog metadata itself is pure and server-safe. Importing `@pascal-app/plugin-environment/lab/catalog` does not initialize a renderer, a Zustand store or a viewer runtime.

## Water truth

Pond water exists only when `analyzePondBasin` accepts the encoded Site terrain and seed. The deterministic lab bowl has a 4 m × 4 m sample span, a four-metre spill level and real 0.25 m level actions. Mixed and combined fixtures use half-metre samples to form a genuine wet depression around a broad low dry island rather than a single-sample spike. Fixture levels come from the accepted bottom/spill ladder. A null level is a real dry Pond state, not a hidden mesh; dry retained variants keep their authored prop records. Connected seeds are separate semantic records resolved by production merge behavior.

River fixtures use `rebuildRiverTerrain`. Their Site metadata preserves baseline terrain and exact applied terrain so width/depth/path revisions do not compound excavation and final deletion can restore the source. Endpoint availability follows the production coast gate. Visible current direction and speed are artistic flow parameters; the plugin does not promise hydraulic simulation, water volume conservation or drainage.

## Presentation and portability

The SceneGraph owns Site terrain and current Environment nodes: Ground Cover, Surface, Pond and River. The versioned Environment sidecar owns surroundings preset/seed/frontages, sky, presentation visibility and weather. Brushes, selection, feedback, authoring drafts, playback and thunder consent are session state and are reset rather than exported.

Live rendering, Review JSON and production model export are related but distinct artifacts:

| Artifact | Current role and observed limits |
|---|---|
| Live scene | Production PBR materials, vegetation, water, surroundings, atmosphere, weather and subsystem-specific motion under the active renderer. |
| Review JSON | The full editable SceneGraph plus versioned Environment configuration, camera/render profile and review notes. |
| Current production GLB | A material-baked static geometry result that must be inspected as emitted. The recorded native Ground Cover export was 59,476,728 bytes with 11 meshes, 10 materials and no `COLOR_0` primitives; those measurements describe that result, not a stable exporter encoding or unrelated exporter paths. |

Keep the Review JSON as the editable Environment document. The GLB is a current production rendering result, not a complete substitute for that document, and no live/export visual-equivalence or blanket presentation inclusion/exclusion contract is implied.

## Motion and lifecycle

Pause behavior is stated per subsystem because there is no universal animation clock:

- Pond koi, distant birds, lighthouse beacon and weather use their current viewer-pause or visibility gates.
- `ambientMotion` controls distant-bird animation independently of bird visibility.
- Thunder requires an explicit user gesture and active session. Reset always disables and closes it.
- The current sky time playback/cloud movement and shader-based Ground Cover/water motion do not establish a universal viewer-pause guarantee. The lab documents this instead of hiding it.
- Page visibility and reduced-motion behavior are reviewed where the current production subsystem implements them, especially lightning/weather.

## Performance review

The lab supplies stable scenes and stations, not a universal performance score. Capture at least:

1. Browser, OS, GPU/backend and viewport/device-pixel ratio.
2. Case ID, version, variant, station and scratch/canonical state.
3. Initial load and steady-state frames separately.
4. Frame time distribution rather than FPS alone.
5. Draw calls, triangles/instances and renderer memory when available.
6. GPU timing when available; otherwise label CPU frame observations honestly.
7. The same rendering profile, camera and duration for comparisons.

Warm-up, shader compilation, texture decode, tree population and weather startup can dominate first-load evidence. Do not compare a warm variant against a cold one. Ground Cover density, natural vegetation, rocky shores, surroundings range and weather overlays are deliberate stress dimensions; isolate one dimension before assigning causality.

## Visual review and evidence

Screenshots and image diffs are useful for fixed-profile regressions, but Environment is view-dependent, animated and GPU-backed. A credible review combines:

- semantic graph/configuration inspection;
- the catalog's case-specific authoring or variant steps;
- stable station captures under one named render profile;
- failure-state and reset checks;
- performance evidence where relevant;
- human perceptual review for scale, material identity, water/terrain contact, distribution and motion.

Downloaded review records should contain the stable case/version/variant, active scratch graph and configuration, camera/station, render profile and reviewer notes. They are discussion artifacts. Acceptance baselines remain independently owned.

### Local verification status

The lab is implemented, but its full browser acceptance checklist is not certified complete. The corrected Living island was inspected in the actual WebGPU renderer and accepted by the user. CPU fixture coverage and recorded native paint, sculpt, water and export observations do not substitute for unexecuted browser scenarios.

Remaining verification gaps:

- Successful targeted Pond prop removal: fast and settled Remove inputs selected the removal branch, but the latest target attempts missed the prop. The earlier unexpected koi placement has not been reproduced or assigned a confirmed production cause.
- Active Pond/River reset sequences, River endpoint controls, and rendered grass recovery after draining the corrected pond.
- The remaining corrected camera/night allocations and sky, surroundings, bird/beacon, visibility, reduced-motion and immediate audio-stop observations.
- The edited Portability case's production GLB export and inspection; the recorded Ground Cover export is a separate successful witness.
- Narrow-case canvas/control usability and source-link navigation preserving the scratch document.

Concurrent development edits interrupted some attempts. An inert Next HMR socket also prevented lazy editor startup, so that instrumentation is not valid evidence; use a source-stable normal browser window or a production build. Never accept an old ready badge beneath a build-error overlay. The plugin's host-aligned typecheck is the integration check; standalone development dependencies still target older host APIs.

## Expected failure and boundary states

These outcomes are part of the documented contract and should remain visible:

| Action | Expected production response |
|---|---|
| Request an unknown catalog case or variant | Fixture creation throws; it never substitutes a default case. |
| Select terrain that is not a contained basin | Pond authoring reports that no pond is available and does not add a node or water plane. |
| Raise a Pond beyond its spill level | The real basin ladder clamps/refuses the level; water never floods arbitrary exterior terrain. |
| Place a lily outside the wet outline or koi without enough depth | Placement is refused; existing props are retained. |
| Finish a River with fewer than two distinct points | Commit remains unavailable; cancel clears preview without a scene edit. |
| Choose Sea for an inland regional seed | The endpoint option is unavailable/refused because the derived landscape has no coast. |
| Enable thunder without an explicit user gesture/session | No audio starts; visual storm behavior remains independent. |
| Treat a production GLB as the editable Environment document | Keep the separate Review JSON with the current SceneGraph and Environment configuration. |
| Expect live visual/motion equivalence or a fixed GLB encoding | Inspect the actual current export; its static representation and limits are exporter-version dependent. |

## Explicit non-promises

The lab does not claim:

- a Nature provider or cloud sidecar sharing feature;
- “Coming soon” systems as shipped behavior;
- universal pause behavior across unrelated clocks and shaders;
- hydraulic river or pond simulation;
- cross-GPU pixel identity;
- live/export visual identity, a fixed GLB encoding, or a blanket rule that presentation is always included or always absent;
- remote issue posting or self-approval of captured evidence.
