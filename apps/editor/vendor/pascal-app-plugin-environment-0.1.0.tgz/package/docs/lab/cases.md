# Environment lab case guide

Every fixture is metric and production-faithful. Camera bookmarks are part of the catalog; use them rather than inventing a close-up that hides scale or context. The first named variant is canonical.

## `surface-materials` — Zoo

**Variants:** `standard-scale` (100%), `fine-scale` (25%), `coarse-scale` (200%).

The four quadrants are real persisted Surface channels: Flowered Grass, Road Path, Desert Ground and Paved Road. The centre cross stores equal weights so Surface → Blend has visible before/after evidence. Inspect terrain drape, material pattern size and the production six-metre feather beyond the Site. Exercise Paint, Blend, Fill site, Clear surface, 2D authored colors and undo. Then run the current production model exporter and inspect its material-baked GLB beside the live result and separate editable Review JSON; no live/export visual-equivalence or fixed encoding contract is promised.

Sources: [schema](../../src/surface-material/schema.ts), [field codec and weights](../../src/surface-material/field.ts), [PBR material assets](../../src/surface-material/materials.ts), [definition and bake](../../src/surface-material/definition.ts).

## `ground-cover-brushes` — Gym

**Variants:** `authored-patches`, `low-density`, `high-wind`.

The fixture begins partly dense/partly sparse with lowered, neutral and raised saved height regions. Use the real round/square Paint, Erase and Smooth density tools, then Raise, Lower and Smooth height. Confirm exact radius, strength, falloff, color/density and height-amount controls. Verify whole-Site Fill, Clear grass and Reset height confirmations and real editor undo/redo. Select the Ground Cover node to inspect blade width/height and variations, rest bend, tint, tip brightness, density, flower density, wind strength and grass-wind influence.

Sources: [schema](../../src/ground-cover/schema.ts), [field codec](../../src/ground-cover/paint-field.ts), [height encoding](../../src/ground-cover/height-field.ts), [brush operations](../../src/ground-cover/paint-stroke.ts), [render geometry](../../src/ground-cover/geometry.ts).

## `grass-obstacles` — Zoo

**Variants:** `wet-water`, `drained-pond`, `water-removed`.

Compare grass at the Building/Level/Slab interior, the freestanding procedural block, the broad low dry island inside its genuine wet basin, the dry bank, the resolved wet pond footprint and the carved river. Painted grass is not destroyed by runtime obstacles: drained water and fully removed water expose the original coverage again. Inspect obstacle bend radius, bend strength and flattening at the solid boundaries. Roots must follow the encoded Site terrain.

Sources: [obstacle collection](../../src/ground-cover/obstacle-adapter.ts), [field context](../../src/ground-cover/field-context.ts), [pond surface](../../src/pond/geometry.ts), [river surface](../../src/river/geometry.ts).

## `pond-basins` — Gym

**Variants:** `filled`, `stepped`, `dry-retained`, `connected-seeds`.

The fixture contains an established deterministic 5 × 5 bowl spanning 4 m × 4 m: one-metre sample spacing, 0.01 m quantization, a zero-metre bottom and an actual four-metre spill at the lowest rim sample. The real level actions move in 0.25 m steps. Use Basin selection, raise/lower, Fill to spill and Empty. Connected seeds are sibling Pond nodes in one accepted catchment and therefore merge as one effective body. Dry retained keeps the semantic pond and its authored props rather than deleting it. No variant uses a decorative plane or bypasses basin analysis.

Sources: [basin resolver](../../src/pond/basin.ts), [actions and connected-body merge](../../src/pond/actions.ts), [Pond tool](../../src/pond/tool.tsx), [schema](../../src/pond/schema.ts).

## `pond-life` — Zoo

**Variants:** `pure-soft`, `clear-rocky`, `deep-life`, `swampy-life`.

Compare all four water qualities under fixed framing. Soft shoreline fades against the actual terrain; Rocky runs the deterministic stone planner around the resolved contour. Use Lilies and Koi on the real wet footprint, then Remove and Clear props. A lily must fit inside the surface and koi require enough resolved depth. Koi motion stops with the viewer pause contract and is independent of the surroundings `ambientMotion` preference.

Sources: [appearance](../../src/pond/appearance.ts), [shoreline](../../src/pond/shoreline.ts), [prop fit and actions](../../src/pond/props.ts), [koi lifecycle](../../src/pond/koi-motion.ts).

## `river-authoring` — Gym

**Variants:** `authored`, `narrow-shallow`, `wide-deep`, `reverse-fast`.

Exercise Draw new river, live channel preview, Remove last point, Cancel/Escape, Finish, Edit path, control-point drag, Delete, editor undo and redo. Change width and depth and confirm every revision rebuilds from preserved source terrain rather than cutting the already-cut field. Delete restores only the river footprint and undo restores the exact river. Direction and speed change current visuals without reshaping the terrain; this is not hydraulic simulation.

Sources: [actions](../../src/river/actions.ts), [terrain grading and source metadata](../../src/river/terrain.ts), [tool](../../src/river/tool.tsx), [controls](../../src/river/controls.tsx).

## `river-endpoints` — Museum

**Variants:** `inland-rounded`, `coastal-mountain-rounded`, `coastal-mountain-sea`, `coastal-rounded-sea`.

The inland fixture uses the fixed `environment-lab-8` seed, whose current `deriveLandscapeRegion` result has no coast; Sea is therefore unavailable. Coastal variants use the proven `pascal-suburbs` seed and a fixed production primary frontage. Rounded endpoints remain internal and compact. Mountain and Sea endpoints reach the property boundary and create real regional continuation; each coastal plan also derives at least one real bridge where that continuation crosses the road graph. Follow the stations to distinguish authored Site river, exterior continuation and bridges. Shoreline and quality are real River controls; flow direction is a visible current, not a water-level solver.

Sources: [coast-gated controls](../../src/river/controls.tsx), [path/terrain semantics](../../src/river/terrain.ts), [regional continuation](../../src/surroundings/river-landscape.ts), [bridge planning](../../src/surroundings/river-bridges.ts).

## `regional-surroundings` — Museum

**Variants:** `mixed-frontages`, `no-roads`, `primary-access`.

Follow the concave property polygon and verify exterior terrain clips to it. A semantic mountain-to-sea River crosses the Site and produces real regional continuation. The mixed configuration carries No road, Secondary and Primary separators plus `none`, `driveway` and `pedestrian-path` access and current `alley`, `local-street`, `collector` and `arterial` style IDs. Inspect generated roads, homes, trees, shared shadows and continuation water. The painted Surface extends through the controlled boundary transition while the Site remains editable. Frontage access/style metadata is part of the versioned sidecar even where today's panel only edits separators.

Sources: [composition](../../src/surroundings/layer.tsx), [frontage model](../../src/surroundings/frontages.ts), [runtime road graph](../../src/surroundings/runtime-road-graph.ts), [river continuation](../../src/surroundings/river-landscape.ts), [shadow batches](../../src/surroundings/neighborhood-shadows.tsx).

## `natural-presets` — Zoo

**Variants:** `open-meadow`, `woodland-edge`, `meadow-still`.

Compare the same Site, seed and camera. Open Meadow emphasizes true-scale low cover, flowers, sparse copses and a long horizon. Woodland Edge emphasizes nearby trees, understory and a distant forest layer while preserving clearings. Natural presets intentionally force inland landscape context and suppress roads, houses, coast and regional river. `meadow-still` disables ambient bird motion while retaining bird visibility; the viewer pause contract also stops flight.

Sources: [preset policies](../../src/surroundings/presets.ts), [vegetation populations](../../src/surroundings/natural-vegetation.tsx), [natural grass](../../src/surroundings/natural-grass.tsx), [distant birds](../../src/surroundings/distant-birds.tsx).

## `night-landmarks` — Museum

**Variants:** `day`, `night`, `sky-disabled`.

All variants use the fixed coastal `environment-lab-night-2295` seed. Its production plan deterministically allocates both a gas station and supermarket with one viable parked car, woodland fields, skyline, boulders and a 24.0 m coastal lighthouse without the road-presentation fallback. The three named stations frame commerce, the combined distant landscape subjects, and the lighthouse rather than proxy coordinates. Compare the exact same derived geometry at 14:00 and midnight. Solar night factor drives opaque window grids, streetlights and lighthouse visibility. The beacon and bird animation stop while viewer rendering is paused. `sky-disabled` demonstrates the real contract: Environment artificial-night factor becomes zero when Environment Sky is off; the plugin does not infer night from UI theme.

Sources: [region derivation](../../src/surroundings/landscape-region.ts), [third-ring planning](../../src/surroundings/third-ring.ts), [night factor and emissive state](../../src/surroundings/night-lighting.ts), [beacon lifecycle](../../src/surroundings/lighthouse-beacon.tsx).

## `sky-and-sun` — Museum

**Variants:** `procedural-noon`, `gradient`, `cloudy`, `golden-hour`, `blue-hour`, `moonlit`, `manual-sun`, `luminance-debug`.

Compare both installed providers and every shipped named preset: Clear day, Cloudy, Golden hour, Blue hour and Moonlit. Time mode is a non-geolocated display clock rather than a location/date solar model; inspect time-of-day and north offset. In Manual mode inspect elevation and azimuth. Advanced controls cover Rayleigh, Mie, Mie anisotropy, turbidity, sun disc/radiance, cloud coverage/softness/scale/speed, fog start/end, moon phase, exposure compensation and every debug view. Time playback and cloud motion are distinct panel flags. Do not infer a universal viewer-pause guarantee: today the sky clock and cloud shader do not share every pause-aware subsystem's gate.

Sources: [settings/presets and solar state](../../src/atmosphere/settings.ts), [provider integration](../../src/atmosphere/sky-provider.ts), [controls](../../src/atmosphere/controls.tsx).

## `weather` — Gym

**Variants:** `clear`, `light-rain`, `rain`, `snow`, `wind`, `storm`, `mixed`.

Compare each weather family separately before Mixed. Inspect real Site, Surface, structure, Pond/River and surroundings meshes for wetness or upward-facing snow. These are immediate overlays, not accumulation, melting, runoff or hydraulics. Lightning is part of Storm and observes actual reduced-motion, page visibility and viewer-pause gates. Thunder is separately opt-in after a user gesture, synthesized locally, and always off after case initialization/reset. Inspect the current production export independently; this case does not promise which presentation contributions or motion an exporter version includes.

Sources: [weather renderer](../../src/atmosphere/weather.tsx), [mesh overlays](../../src/atmosphere/weather-surfaces.tsx), [audio session](../../src/atmosphere/weather-audio.ts), [reduced-motion preference](../../src/atmosphere/weather-preferences.ts).

## `portability` — Museum

**Variants:** `live-presentation`, `presentation-hidden`, `dry-authored-water`.

Inspect the graph and sidecar independently. The graph has one proper Site and direct Ground Cover, Surface, Pond and River children, plus a proper Building → Level → Slab/Block reference hierarchy. It includes encoded terrain and RGBA authoring fields and declares `pascal:environment`. The sidecar contains version, preset, seed, frontages, sky, visibility and weather. It excludes brushes, selections, authoring drafts, time playback and thunder consent. Presentation hidden changes sidecar visibility without deleting nodes; Dry authored water retains its Pond node with a null level.

The live renderer uses bundled PBR texture assets and animation. Run the current production model exporter and inspect the GLB it actually emits rather than inferring an encoding or blanket presentation inclusion/exclusion rule. The current result is material-baked static geometry, so live motion or visual equivalence is not promised. Keep the downloaded Review JSON as the separate editable record of the current SceneGraph and Environment configuration; it also carries camera/render profile and notes as review evidence, not a self-accepted baseline.

Sources: [plugin definitions](../../src/index.ts), [sidecar schema/import/export](../../src/presentation.tsx), [Ground Cover bake](../../src/ground-cover/bake-geometry.ts), [River static renderer](../../src/river/static-renderer.tsx).

## `living-landscape` — Museum

**Variants:** `daylight`, `storm`, `night`, `dry-pond`.

Follow the fixed stations in order: authored Site, basin/koi/island, rocky curved river, regional boundary and atmosphere. The fixture combines a concave/sloped encoded Site, four-channel Surface, flowered local-height Ground Cover, solid and wet exclusions, a genuine wet depression surrounding a broad low dry island with viable Pond life, source-backed River grading, regional frontage/context, real Environment sky and weather. Daylight is the canonical clear comparison. Storm enables rain, strong wind and lightning but never thunder consent. Night uses the real Moonlit state and regional night response. Dry Pond retains the Pond and prop records and exposes non-destructive grass reappearance.

Sources: [presentation composition](../../src/presentation.tsx), [Ground Cover context](../../src/ground-cover/field-context.ts), [River/regional bridge](../../src/surroundings/river-landscape.ts), [atmosphere composition](../../src/atmosphere/layer.tsx).
